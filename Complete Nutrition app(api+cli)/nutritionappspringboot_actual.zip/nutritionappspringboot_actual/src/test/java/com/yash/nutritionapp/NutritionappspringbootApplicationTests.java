package com.yash.nutritionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionappspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
