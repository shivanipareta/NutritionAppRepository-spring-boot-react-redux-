package com.yash.nutritionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutritionappspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutritionappspringbootApplication.class, args);
	}

}
