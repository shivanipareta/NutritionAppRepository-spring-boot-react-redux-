package com.yash.nutritionapp;

/**
 * Enum for creating user status
 * @author Vanshika Chaturvedi
 *
 */
public enum UserStatus {
	ACTIVE, BLOCKED

}
