package com.yash.nutritionapp.exceptions;

public class DietPlanIdException extends Exception {

	

	public DietPlanIdException(String string) {
		// TODO Auto-generated constructor stub
	}

}
