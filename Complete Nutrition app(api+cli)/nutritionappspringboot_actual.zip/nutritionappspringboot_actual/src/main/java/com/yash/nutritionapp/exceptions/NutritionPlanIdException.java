package com.yash.nutritionapp.exceptions;

public class NutritionPlanIdException extends Exception {
	
	public NutritionPlanIdException(String msg)
	{
		
	}

}
