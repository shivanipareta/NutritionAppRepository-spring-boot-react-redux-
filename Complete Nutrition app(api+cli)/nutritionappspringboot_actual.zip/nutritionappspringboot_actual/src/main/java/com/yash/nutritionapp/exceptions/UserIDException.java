package com.yash.nutritionapp.exceptions;

/**
 * Throws exception if user id is same
 * @author Vanshika Chaturvedi
 *
 */
public class UserIDException extends Exception {

	
	public UserIDException(String string) {
		
	}

}
