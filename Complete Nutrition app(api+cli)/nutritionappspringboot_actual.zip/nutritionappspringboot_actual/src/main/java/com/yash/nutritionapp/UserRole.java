package com.yash.nutritionapp;

/**
 * Enum for creating user roles
 * @author Vanshika Chaturvedi
 *
 */
public enum UserRole {
ADMIN, USER
}
