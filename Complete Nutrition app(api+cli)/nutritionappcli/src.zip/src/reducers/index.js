import {combineReducers} from 'redux';
import errorReducer from './errorReducer';
import PaymentReducer from './PaymentReducer';
import nutritionPlanReducer from './nutritionPlanReducer';
export default combineReducers ({
    errors: errorReducer,
    payments:PaymentReducer,
    nutritionplans:nutritionPlanReducer
});