import React from 'react';
import './App.css';
import DashboardPayment from './components/DashboardPayment';
import "bootstrap/dist/css/bootstrap.min.css";
import {BrowserRouter as Router,Route} from "react-router-dom";
import AddPayment from './components/payments/AddPayment';
import {Provider} from "react-redux";
import store from './store';
import UpdatePayment from './components/payments/UpdatePayment';
import NutritionPlan from './components/NutritionPlan';
import Header from './components/Header';
import ViewNutritionPlans from './components/nutritionplan/ViewNutritionPlans';
import CreateNutritionPlan from './components/nutritionplan/CreateNutritionPlan';
import UpdateNutritionPlan from './components/nutritionplan/UpdateNutritionPlan';

class App extends React.Component{
  render(){
    return(
      <Provider store={store}>
      <Router>
        <div className="App">
          <Header/>
          <Route path="/nutritionplan" component={NutritionPlan}/>
          <Route path="/viewnutritionplans" component={ViewNutritionPlans}/>
          <Route path="/createnutritionplan" component={CreateNutritionPlan}/>
          <Route path="/updatenutritionplan/:id" component={UpdateNutritionPlan}/>
          <Route path="/payment" component={DashboardPayment}/>
          <Route path="/addProject" component={AddPayment}/>
          <Route path="/updateProject/:id" component={UpdatePayment}/>
          </div>
      </Router>
      </Provider>
    );
  }
}

export default App;

